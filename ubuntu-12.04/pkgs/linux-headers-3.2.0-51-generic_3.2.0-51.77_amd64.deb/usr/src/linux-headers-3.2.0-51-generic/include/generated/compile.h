/* This file is auto generated, version 77-Ubuntu */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#77-Ubuntu SMP Wed Jul 24 20:18:19 UTC 2013"
#define LINUX_COMPILE_BY "buildd"
#define LINUX_COMPILE_HOST "allspice"
#define LINUX_COMPILER "gcc version 4.6.3 (Ubuntu/Linaro 4.6.3-1ubuntu5) "
