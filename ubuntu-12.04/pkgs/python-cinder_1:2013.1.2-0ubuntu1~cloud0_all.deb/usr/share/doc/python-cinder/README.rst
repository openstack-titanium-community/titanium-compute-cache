The Choose Your Own Adventure README for Cinder
===============================================

You have come across a storage service for an open cloud computing service.
It has identified itself as "Cinder."   It was abstracted from the Nova project.

To monitor it from a distance: follow `@openstack <http://twitter.com/openstack>`_ on twitter.

To tame it for use in your own cloud: read http://docs.openstack.org

To study its anatomy: read http://cinder.openstack.org

To dissect it in detail: visit http://github.com/openstack/cinder

To taunt it with its weaknesses: use http://bugs.launchpad.net/cinder

To watch it: http://jenkins.openstack.org

To hack at it: read HACKING

To cry over its pylint problems: http://jenkins.openstack.org/job/cinder-pylint/violations
