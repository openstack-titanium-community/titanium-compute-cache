
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
short_version = '1.6.1'
version = '1.6.1'
full_version = '1.6.1'
git_revision = '68538b74483009c2c2d1644ef00397014f95a696'
release = True

if not release:
    version = full_version
